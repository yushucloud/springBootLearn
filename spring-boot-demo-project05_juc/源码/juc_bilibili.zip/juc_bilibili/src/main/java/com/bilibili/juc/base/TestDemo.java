package com.bilibili.juc.base;

import org.omg.PortableInterceptor.ACTIVE;

import java.lang.invoke.VolatileCallSite;
import java.security.AccessControlContext;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @auther zzyy
 * @create 2022-01-21 12:48
 */
public class TestDemo
{
    volatile int age;

    public static void main(String[] args)
    {

    }

}