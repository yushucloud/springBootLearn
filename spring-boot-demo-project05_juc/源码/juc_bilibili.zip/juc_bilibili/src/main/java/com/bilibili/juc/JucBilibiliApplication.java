package com.bilibili.juc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JucBilibiliApplication
{

    public static void main(String[] args)
    {
        SpringApplication.run(JucBilibiliApplication.class, args);
    }

}
